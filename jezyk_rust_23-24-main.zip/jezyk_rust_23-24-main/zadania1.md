1. Napisz program, który wyświetla informację o przestępności danego roku.
2. Napisz program, który wyświetla liczbę dni miesiąca na podstawie jego numeru i numeru roku.
3. Napisz program służący do konwersji wartości temperatury podanej w stopniach Celsjusza na stopnie w skali Fahrenheita; F=32+(9/5)C
4. I odwrotnie.
5. Napisz program, który dla danych dwóch poprawnych pór jednej doby (w postaci całkowitych godzin, minut i sekund) wyświetla różnicę czasów (także w postaci analogicznej trójki, z minutami i sekundami w przedziale [0;59]).
