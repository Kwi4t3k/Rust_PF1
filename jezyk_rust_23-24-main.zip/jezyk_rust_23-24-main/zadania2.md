1. Napisz program, który oblicza silnię dla danej liczby.
2. Napisz program, który wyświetla cyfry danej liczby całkowitej od końca.
3. Napisz program, który oblicza sumę cyfr danej liczby całkowitej.
4. Napisz program, który znajduje wszystkie trójki pitagorejskie o wartościach
   nie większych niż dana. Zakładamy, że 0 < a < b < c. 
5. Zmodyfikuj kod z zadań 1-4 tak, aby stanowiły one osobne funkcje.
6. Zaimplementuj wyznaczanie pierwiastków funkcji rzeczywistej *f* [metodą
   Newtona](https://pl.wikipedia.org/wiki/Metoda_Newtona) w postaci funkcji,
   która zrealizuje liczbę kroków algorytmu przekazaną w argumencie. Wyodrębnij
   funkcję, która zwróci znak pochodnej *f'* w punkcie. Obliczanie wartości
   funkcji *f* zrealizuj funkcją wpisaną "na twardo" w implementację metody
   Newtona.
