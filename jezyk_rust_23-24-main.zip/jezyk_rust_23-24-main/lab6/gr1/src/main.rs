fn szyfruj(tekst: &String, klucz: usize) -> String {

}

fn main() {
    let imie = String::from("onufry");
    let wyjscie = od_tylu(&imie);
    println!("{}", &wyjscie);
}
